"""
3. Modifica el ejercicio de POO que gestiona una cuenta bancaria con movimientos, de forma que añadas a la clase un
método para guardar todos los datos de la cuenta bancaria (número, saldo y movimientos) en un fichero elegido por el
cliente, y un nuevo constructor que reciba como parámetro un fichero como el anterior y cree el objeto con esos datos.
Pruébalo con un programa.

Autor: Pablo Mérida Velasco
Curso: 1º DAW A
Fecha: 18/04/2023
"""


