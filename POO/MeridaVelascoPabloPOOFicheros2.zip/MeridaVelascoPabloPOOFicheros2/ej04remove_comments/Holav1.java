//Esto es un Hola mundo en java
public class HolaMundo {
    public static void main(String[] args) {
        System.out.println("Hola Mundo");
    }
}
//Aqui acaba el programa
/*
Esto es un comentario largo
*/